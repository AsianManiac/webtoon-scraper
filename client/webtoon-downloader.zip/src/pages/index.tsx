export { default as Home } from "./Home"
export { default as Downloads } from "./Downloads"
export { default as CompletedDownloads } from "./CompletedDownloads"
export { default as InProgressDownloads } from "./InProgressDownloads"
export { default as FailedDownloads } from "./FailedDownloads"
export { default as ToonDetails } from "./ToonDetails"
export { default as ChapterView } from "./ChapterView"

