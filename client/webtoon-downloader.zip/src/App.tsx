import { BrowserRouter as Router, Route, Routes } from "react-router-dom"
import { AnimatePresence } from "framer-motion"
import Navbar from "./components/Navbar"
import { WebSocketProvider } from "./contexts/websocket-context"
import * as Pages from "./pages"

function App() {
  return (
    <WebSocketProvider>
      <Router>
        <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
          <Navbar />
          <main className="container mx-auto px-4 py-8">
            <AnimatePresence mode="wait">
              <Routes>
                <Route path="/" element={<Pages.Home />} />
                <Route path="/downloads" element={<Pages.Downloads />} />
                <Route path="/completed" element={<Pages.CompletedDownloads />} />
                <Route path="/in-progress" element={<Pages.InProgressDownloads />} />
                <Route path="/failed" element={<Pages.FailedDownloads />} />
                <Route path="/toon/:id" element={<Pages.ToonDetails />} />
                <Route path="/toon/:id/chapter/:chapterId" element={<Pages.ChapterView />} />
              </Routes>
            </AnimatePresence>
          </main>
        </div>
      </Router>
    </WebSocketProvider>
  )
}

export default App

