"use client"

import  from "../web-server"

export default function SyntheticV0PageForDeployment() {
  return < />
}